function y = Conductivity(x)
y = 0.1*(5 - 0.6*x); % heat conductivity times area
