function g = gN2(x,y)
g=0;
