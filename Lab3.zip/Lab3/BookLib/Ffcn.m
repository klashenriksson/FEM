function z = Ffcn(x,y)
z=1;
