function y = Source(x)
y = 0.03*(x-6)^4; % heat source
