function y = Foo1(x)
y=x.*sin(x)
