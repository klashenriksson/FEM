function z = Afcn(u)
z=0.125+u.^2;
