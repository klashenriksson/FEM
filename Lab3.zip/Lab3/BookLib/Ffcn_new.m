function z = Ffcn(x,y)
z=x.^0; % =1