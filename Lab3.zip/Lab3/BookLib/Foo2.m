function f = Foo2(x, y)
f = x.*y;
