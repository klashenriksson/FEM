function z = gD1(x,y)
z=0;
