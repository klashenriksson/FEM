function g = gD2(x,y)
g=0;
if sqrt(x^2+y^2)<1.01, g=1; end
