function z = Kappa1(x,y)
z=0;
if (x>29.99), z=1.e+6; end
