function nl = NonLinLoadVectorComp(A,uk)
    nl = A*uk;
end

